import os
import pandas as pd
import dill


def load_model(model_path):
    with open(model_path, 'rb') as f:
        model = dill.load(f)
    return model


def make_predictions(model, test_data_path):
    df_test = pd.read_csv(test_data_path)
    predictions = model.predict(df_test)
    return predictions


def save_predictions(predictions, save_path):
    df_predictions = pd.DataFrame(predictions, columns=['predictions'])
    df_predictions.to_csv(save_path, index=False)


def predict():
    project_path = os.environ.get('PROJECT_PATH', '.')
    model_path = os.path.join(project_path, 'data', 'model', 'model.pkl')
    test_data_path = os.path.join(project_path, 'data', 'test', 'test_data.csv')
    predictions_save_path = os.path.join(project_path, 'data', 'predictions', 'predictions.csv')

    model = load_model(model_path)
    predictions = make_predictions(model, test_data_path)
    save_predictions(predictions, predictions_save_path)


if __name__ == "__main__":
    predict()
